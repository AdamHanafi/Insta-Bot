# flake8: noqa
from .settings import Settings
from .instapy import InstaPy
